#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
import pytest


@pytest.fixture(scope="session")  # scope="session"
def set_up_browser():
    options = Options()
    options.page_load_strategy = 'eager'  # Ждет загрузку HTML, но не ждет загрузку файлов
    options.add_argument('--no-sandbox')
    #options.add_argument('--headless=new')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--ignore-certificate-error')
    options.add_argument('--ignore-ssl-errors')
    driver = webdriver.Chrome(options=options)
    #driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    driver.set_window_size(1980, 1200)
    yield driver
    driver.close()
