import os
import requests
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# Переменные окружения
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_USERNAME = os.getenv("GITHUB_USERNAME")
REPO_NAME = os.getenv("REPO_NAME")

# Заголовки для аутентификации
headers = {
    "Authorization": f"token {GITHUB_TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

# Базовый URL API
BASE_URL = "https://api.github.com"

def test_create_repository():
    """Создать репозиторий на GitHub."""
    url = f"{BASE_URL}/user/repos"
    data = {
        "name": REPO_NAME,
        "private": False
    }
    response = requests.post(url, json=data, headers=headers)
    if response.status_code == 201:
        print(f"Репозиторий {REPO_NAME} успешно создан.")
    else:
        print(f"Не удалось создать репозиторий: {response.json()}")

def test_check_repository_exists():
    """Проверить наличие репозитория."""
    url = f"{BASE_URL}/repos/{GITHUB_USERNAME}/{REPO_NAME}"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        print(f"Репозиторий {REPO_NAME} существует.")
    else:
        print(f"Репозиторий {REPO_NAME} не найден.")

def test_delete_repository():
    """Удалить репозиторий на GitHub."""
    url = f"{BASE_URL}/repos/{GITHUB_USERNAME}/{REPO_NAME}"
    response = requests.delete(url, headers=headers)
    if response.status_code == 204:
        print(f"Репозиторий {REPO_NAME} успешно удален.")
    else:
        print(f"Не удалось удалить репозиторий: {response.json()}")

if __name__ == "__main__":
    test_create_repository()
    test_check_repository_exists()
    test_delete_repository()