pytest_plugins = [
    "src.browser"
]
