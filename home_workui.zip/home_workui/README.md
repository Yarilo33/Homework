# Тестирование процесса покупки на saucedemo.com

## Описание
Этот проект реализует автоматический e2e тест для проверки сценария покупки товара на сайте [saucedemo.com](https://www.saucedemo.com). Тест проходит этапы авторизации, выбора товара, оформления покупки и проверки завершения заказа.

## Установка

1. Клонируйте репозиторий:

   ```bash
   git clone https://gitlab.com/alpin331/home_workui.git
   
2. Установите зависимости:
    ```bash
    pip install -r requirements.txt
    Убедитесь, что у вас установлен Google Chrome и Python.

3. Запустите тест следующим образом:
    ```bash
    pytest tests/test_1.py 
    или запустить последний прогон в GitLab по ссылке https://gitlab.com/alpin331/home_workui/-/pipelines/1451965113