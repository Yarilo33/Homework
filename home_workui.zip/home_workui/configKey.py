from selenium.webdriver.common.by import By
from dotenv import load_dotenv
import string
import testit
import time
import os


# Загрузка переменных окружения из файла .env
load_dotenv()

link = 'https://www.saucedemo.com/'
username='standard_user'
password='secret_sauce'