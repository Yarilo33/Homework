from selenium.webdriver.support import expected_conditions as EC

import configKey
import shutil
import Page_locators
import random
import string
import testit
import pytest
import time
import os

from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait


class TestAts:
    @testit.workItemIds(1)
    @testit.displayName('Оформление заказа')
    @testit.externalId("001")
    @testit.title("тесты")
    @testit.description("profile_tarif_i_opcii")
    @testit.labels("profile_tarif_i_opcii")
    @testit.step('Успешная авторизация в ЛК')
    @pytest.mark.multithreaded
    def test_93236(self, set_up_browser):
        driver = set_up_browser
        driver.get(configKey.link)
        try:
            with testit.step('Вести имя пользователя'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.username))).send_keys(configKey.username)
            with testit.step('Вести пароль'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.password))).send_keys(configKey.password)
            with testit.step('Нажать кнопку зарегистрироваться'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.login_btn))).click()
            time.sleep(2)#ожидание открытия страницы пользователя
            with testit.step('Добавить в корзину один товар (например, "Sauce Labs Backpack")'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.add_to_curt_back_pack))).click()
            with testit.step('Перейти в корзину'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.curt_btn))).click()
            time.sleep(2)  # ожидание открытия корзины
            with testit.step('убедиться, что товар добавлен'):
                WebDriverWait(driver, 20).until(EC.text_to_be_present_in_element(
                    (By.XPATH, Page_locators.back_pack_check), 'Sauce Labs Backpack'))
            with testit.step('Нажать на кнопку оформить заказ'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.checkout_btn))).click()
            with testit.step('Заполнить поле Имя'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.first_name))).send_keys('Name')
            with testit.step('Заполнить поле Фамилия'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.last_name))).send_keys('LastName')
            with testit.step('Заполнить поле Почтовый код'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.postal_code))).send_keys('1111')
            with testit.step('Нажать на кнопку Продолжить'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.continue_btn))).click()
            with testit.step('убедиться, что товар выбран верно'):
                WebDriverWait(driver, 20).until(EC.text_to_be_present_in_element(
                    (By.XPATH, Page_locators.back_pack_check), 'Sauce Labs Backpack'))
            with testit.step('Нажать на кнопку завершить заказ'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.finish_btn))).click()
            with testit.step('Убедиться, что покупка завершена успешно.'):
                WebDriverWait(driver, 20).until(EC.visibility_of_element_located
                                                ((By.XPATH, "//*[.='Thank you for your order!']")))
            with testit.step('Вернуться на страницу товаров'):
                WebDriverWait(driver, 20).until(EC.element_to_be_clickable
                                                ((By.XPATH, Page_locators.back_home))).click()
        except Exception as e:
            characters = string.ascii_letters + string.digits
            length = 10  # Длина комбинации
            now = ''.join(random.choice(characters) for _ in range(length))
            driver.get_screenshot_as_file(f"BUG_{now}.png")
            time.sleep(1)
            #os.remove(f"BUG_{now}.png")
            raise e
