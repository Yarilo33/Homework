####страница регистрации
password="//input[@id='password']"#поле ввода пароля на странице регистрации
username="//input[@id='user-name']"#поле ввода логина
login_btn="//input[@id='login-button']"#кнопка зарегистрироваться

####страница товаров
add_to_curt_back_pack="//button[@id='add-to-cart-sauce-labs-backpack']"#кнопка добавления в корзину рюкзака
curt_btn="//span[@class='shopping_cart_badge']"

####оформление заказа
checkout_btn="//button[@id='checkout']"#кнопка оформить покупки
first_name="//input[@id='first-name']"#поле ввода имени при оформлении заказа
last_name="//input[@id='last-name']"#поле ввода фамилии при оформлении заказа
postal_code="//input[@id='postal-code']"#поле ввода потчового кода
continue_btn="//input[@id='continue']"#кнопка продолжить оформление
finish_btn="//button[@id='finish']"#кнопка завершить оформление
back_home="//button[@id='back-to-products']"#кнопка обратно на страницу продуктов
back_pack_check="//div[@class='inventory_item_name']"#проверка названия товара после завершения заказа